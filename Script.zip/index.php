﻿<?php
if (!(include "functions/database.php")) {
    echo "<a href='install/index.html'>Please Install the script first or make sure it is installed correctly.</a>";
    exit;
}
include "functions/count.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);

$ads = $db->query("SELECT * FROM ads");
$ads_info = $db->fetch_array($ads);
session_start();

$_SESSION["allow"] = true;
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <!--OG 1-->
    <title><?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics</title>
    <meta name="title" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">
    <meta name="description" content="Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">
    <meta property="og:type" content="website">
    <meta property="og:description" content="Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">
    <meta name="twitter:description" content="Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta itemprop="title" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">
    <meta itemprop="name" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">
    <meta itemprop="description" content="Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DCTERMS.abstract" content="Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DC.title" lang="id-ID" content="<?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics">

    <?php
        include "functions/og2.php";
        include "functions/metawebapp.php";
    ?>

    <?php
        $logo_url = $info['logo_url'];
        if (strpos($logo_url,";")) {
            $logo_url = explode(";",$logo_url);
            if (empty($logo_url[1])) {
                $logo_url[1] = $logo_url[0];
            }
        } else {
            $logo_url = [$logo_url,$logo_url];
        }
    ?>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="css/animate.css?<?php echo $version; ?>" rel="stylesheet">
    <!-- Custom CSS for the Template -->
    <link href="css/style.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>

    <?php
        include "functions/css.php";
        include "functions/googleanalytics.php";
        include "functions/schema.php";
    ?>

</head>
<body>
    
    <h1 class="sr-only"><?php echo $info['name']; ?> - Links Shortener with QR Code and Statistics</h1>
    <h2 class="sr-only">Links Shortener with QR Code and Statistics</h2>
    <h3 class="sr-only"><?php echo $info['name']; ?></h3>

    <?php
    include "functions/menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "functions/logo.php";
                include "functions/darkmode.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated fadeIn bodynew" style="max-width: 950px;">
        <form  action="create.php" method="POST" enctype="multipart/form-data">

            <div class="row">
                <div class="col-lg-12">
                    <div class="input-group">
                        <input class="form-control cz-shorten-input" id="urlbox" type="url" name="longurl" autocomplete="off" placeholder="https:// or http://" value="" data-validation-error-msg=" " required>
                        <div class="input-group-btn">
                            <button class="btn btn-large btn-primary cz-shorten-btn" type="submit" id="submit">Short URL</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-10">
                <div class="col-lg-6">
                    <div class="input-group" style="margin-top: 2px;">
                        <span class="input-group-addon"><?php echo $info['URL']; ?>/</span>
                        <input type="text" autocomplete="off" id="cust" data-validation="alphanumeric" data-validation-allowing="-_" data-validation-optional="true" data-validation-error-msg=" " name="cust" class=" span5 form-control" placeholder="Custom Link (optional)">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="input-group" style="margin-top: 2px;">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="text" autocomplete="off" data-validation="alphanumeric" data-validation-allowing="-_" data-validation-optional="true" data-validation-error-msg=" " id="pass" name="pass" class="form-control" placeholder="Password (optional)">
                    </div>
                </div>
            </div>
        </form>
        <div class="row mt-20 mb-20">
            <div class="col-lg-12" style="text-align: center;">
                <?php echo '' . $ads_info['ad1'] . ''; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 text-center">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h2 class="newsize" style="font-weight:bolder;"> Total Hits </h2> 
                        <div class="newsize" style="letter-spacing:1px;">18503<?php echo $num_rows3; ?></div>
                    </div>
                </div>            
            </div>
            <div class="col-lg-4 text-center">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h2 class="newsize" style="font-weight:bolder;"> Total URLs </h2>
                        <div class="newsize" style="letter-spacing:1px;">4620<?php echo $num_rows1; ?></div>
                    </div>
                </div>            
            </div>
            <div class="col-lg-4 text-center">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h2 class="newsize" style="font-weight:bolder;"> Today URLs </h2> 
                        <div class="newsize" style="letter-spacing:1px;">2<?php echo $num_rows2; ?></div>
                    </div>
                </div>            
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
    <script src="js/bootstrap.js?<?php echo $version; ?>"></script>
    <script src="js/jquery.form-validator.min.js?<?php echo $version; ?>"></script>
    <script>
        $.validate({
            modules: 'security'
        });
    </script>

    <?php
        include "functions/js.php";
    ?>

</body>
</html>
<?php $db->close_connection(); ?>