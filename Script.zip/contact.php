﻿<?php
include "functions/database.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_GET["op"] == "contact") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $comment = $_POST["message"];
  $ip = $_POST['ip'];
  $sub = "New Message";
  $to = $info['email'];
  $subject = $sub;
  $message = 'Message: ' . $comment . ' Email: ' . $email . ' Name: ' . $name . ' IP: ' . $ip;
  $headers = 'From: ' . $info['email'] . '' . "\r\n" . 'Reply-To: ' . $info['email'] . '' . "\r\n" . 'X-Mailer: PHP/' . phpversion();

  mail($to, $subject, $message, $headers);
  include "functions/thankyou.php";
  exit();
} else {

  ?>

  <!DOCTYPE html>
  <html lang="en-US">
  <head>
    <!--OG 1-->
    <title>Contact - <?php echo $info['name']; ?></title>
    <meta name="title" content="Contact - <?php echo $info['name']; ?>">
    <meta name="description" content="Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="Contact - <?php echo $info['name']; ?>">
    <meta property="og:type" content="article">
    <meta property="og:description" content="Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="Contact - <?php echo $info['name']; ?>">
    <meta name="twitter:description" content="Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta itemprop="title" content="Contact - <?php echo $info['name']; ?>">
    <meta itemprop="name" content="Contact - <?php echo $info['name']; ?>">
    <meta itemprop="description" content="Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DCTERMS.abstract" content="Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DC.title" lang="id-ID" content="Contact - <?php echo $info['name']; ?>">
    
    <?php
        include "functions/og2.php";
        include "functions/metawebapp.php";
    ?>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
    <!-- Custom CSS for the 'Full' Template -->
    <link href="css/style.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="css/animate.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <style>
      <?php echo $info['cstm-style']; ?>
    </style>

    <?php
        include "functions/css.php";
        include "functions/googleanalytics.php";
        include "functions/schema.php";
    ?>

    <!--WebPage-->
    <script type="application/ld+json">
        {
          "@context": "http://schema.org",
          "@type": "WebPage",
          "@id": "#WebPage",
          "name": "Contact <?php echo $info['name']; ?>",
          "alternateName": "Contact - <?php echo $info['name']; ?>",
          "headline": "Contact <?php echo $info['name']; ?>",
          "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
          "description": "Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
          "disambiguatingDescription": "Contact - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
          "keywords":["shortlink","safelink","url shortener"],
          "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
          "image": {
              "@type": "ImageObject",
              "@id": "#Image",
              "inLanguage": "id-ID",
              "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
              "caption": "Contact <?php echo $info['name']; ?>"
          },
          "inLanguage": "id-ID",
          "sameAs": [
              "https://www.facebook.com/mycodingxd",
              "https://www.twitter.com/mycodingxd",
              "https://www.instagram.com/mycodingxd",
              "https://www.youtube.com/c/mycodingxd"
          ],
          "potentialAction": {
              "@type": "SearchAction",  
              "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
              "query-input": "required name=search_term_string"
          },
          "speakable": {
            "@type": "SpeakableSpecification",
            "xpath": [
              "/html/head/title",
              "/html/head/meta[@name='description']/@content"
            ]
          },
          "publisher": {"@id": "#Organization"},
          "sponsor": {"@id": "#Corporation"},
          "isPartOf": {"@id": "#WebSite"},
          "mainEntityOfPage": "true",
          "isFamilyFriendly": "true",
          "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
          "creator": "<?php echo $info['name']; ?>",
          "accountablePerson": "<?php echo $info['name']; ?>",
          "copyrightYear": "<?php echo date('Y'); ?>",
          "copyrightHolder": "<?php echo $info['name']; ?>"
        }
    </script>

  </head>

  <body>

    <h1 class="sr-only">Contact - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">Contact <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">Contact</h3>

    <?php 
    include "functions/menu.php";
    ?>

    <div class="container logonew">
      <div class="row logo">
        <div class="col-lg-12" style="text-align:center">
          <?php 
          include "functions/logo.php";
          include "functions/darkmode.php";
          ?>
        </div>
      </div>
    </div>

    <div class="container animated fadeIn bodynew">
      <div class="row mt-20">
        <div class="col-md-10 col-md-offset-1">
          <div class="well">
            <form class="form-horizontal" action="contact?op=contact" method="post">
              <fieldset>
                <legend class=""><h2 style="margin:0">Contact us</h2></legend>

                <!-- Name input-->
                <div class="form-group">
                  <label class="col-md-2 control-label" for="name">Name</label>
                  <div class="col-md-10">
                    <input id="name" name="name" type="text" placeholder="Your name"  class="form-control">
                  </div>
                </div>

                <!-- Email input-->
                <div class="form-group">
                  <label class="col-md-2 control-label" for="email">Your E-mail</label>
                  <div class="col-md-10">
                    <input id="email" name="email" type="text" placeholder="Your email" data-validation="email" data-validation-error-msg="Please enter a valid email" class="form-control">
                  </div>
                </div>

                <!-- Message body -->
                <div class="form-group">
                  <label class="col-md-2 control-label" for="message">Your message</label>
                  <div class="col-md-10">
                    <textarea class="form-control" id="message" name="message" data-validation="required" data-validation-error-msg="Please enter Message" placeholder="Please enter your message here..." rows="5"></textarea>
                  </div>
                </div>

                <!-- Form actions -->
                <div class="form-group">
                  <div class="col-md-12 text-right">
                    <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?> ">
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>


  <!-- JavaScript -->
  <script src="js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
  <script src="js/bootstrap.js?<?php echo $version; ?>"></script>
  <script src="js/jquery.form-validator.min.js?<?php echo $version; ?>"></script>
  <script>
    $.validate({
      modules: 'security'
    });
  </script>

  <?php
      include "functions/js.php";
  ?>

</body>
</html>
<?php
}
?>
