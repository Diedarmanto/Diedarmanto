<!--WebSite-->
<script type="application/ld+json">
  {
    "@context": "http://schema.org",
    "@type": "WebSite",
    "@id": "#WebSite",
    "name": "<?php echo $info['name']; ?>",
    "alternateName": "Links Shortener with QR Code and Statistics",
    "headline": "<?php echo $info['name']; ?>",
    "url": "<?php echo $info['URL']; ?>",
    "description": "Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
    "disambiguatingDescription": "Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. - 401XD Group",
    "keywords":["shortlink","safelink","url shortener"],
    "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
    "image": {
      "@type": "ImageObject",
      "@id": "#ImageWebSite",
      "inLanguage": "ID",
      "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
      "caption": "<?php echo $info['name']; ?>"
    },
    "inLanguage": "ID",
    "sameAs": [
      "https://www.facebook.com/mycodingxd",
      "https://www.twitter.com/mycodingxd",
      "https://www.instagram.com/mycodingxd",
      "https://www.youtube.com/c/mycodingxd"
    ],
    "potentialAction": {
      "@type": "SearchAction",  
      "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "publisher": {"@id": "#Organization"},
    "sponsor": {"@id": "#Corporation"}
  }
</script>
<!--Organization-->
<script type="application/ld+json">
  {
    "@context": "https://schema.org/",
    "@type": "Organization",
    "@id": "#Organization",
    "url": "<?php echo $info['URL']; ?>",
    "name": "<?php echo $info['name']; ?>",
    "description": "Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
    "sameAs": [
      "https://www.facebook.com/mycodingxd",
      "https://www.twitter.com/mycodingxd",
      "https://www.instagram.com/mycodingxd",
      "https://www.youtube.com/c/mycodingxd"
    ],
    "logo": {
      "@type": "ImageObject",
      "@id": "#LogoOrganization",
      "inLanguage": "ID",
      "url": "<?php echo $info['URL']; ?>/img/safelink/safelink-512.png",
      "caption": "<?php echo $info['name']; ?>"
    },
    "image": {
      "@type": "ImageObject",
      "@id": "#ImageOrganization",
      "inLanguage": "ID",
      "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
      "caption": "<?php echo $info['name']; ?>"
    },
    "address": {
      "@type": "PostalAddress",
      "@id": "#PostalAddressOrganization",
      "streetAddress": "401XD Group, Jl. Sumbawa, Ulak Karang Utara, Kec. Padang Utara",
      "addressLocality": "Kota Padang",
      "addressRegion": "Sumatera Barat",
      "postalCode": "25133",
      "addressCountry": "Indonesia"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "<?php echo date('m'); ?>"
    },
    "review": {
        "@type": "Review",
        "@id": "#ReviewOrganization",
        "name": "Review MC Project",
        "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
        "description": "Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
        "reviewRating": {
            "@type": "Rating",
            "ratingValue": "4.9",
            "worstRating": "1",
            "bestRating": "5"
        }
    }
  }
</script>
<!--Corporation-->
<script type="application/ld+json">
  {
    "@context": "https://schema.org/",
    "@type": "Corporation",
    "@id": "#Corporation",
    "url": "https://401xd.com",
    "name": "401XD Group",
    "alternateName": "401XD Group Indonesia",
    "description": "401XD Group adalah perusahaan yang memiliki spesialisasi dalam bidang teknologi, pengembangan software, kecerdasan buatan, internet, portal media online, digital marketing, teknologi finansial dan e-commerce di Indonesia.",
    "disambiguatingDescription": "401XD Group adalah perusahaan yang memiliki spesialisasi dalam bidang teknologi, pengembangan software, kecerdasan buatan, internet, portal media online, digital marketing, teknologi finansial dan e-commerce di Indonesia. Berawal dari sebuah organisasi komunitas pada tahun 2009, 401XD Group saat ini berdiri sebagai perusahaan yang memiliki 20+ startup penyedia produk, layanan jasa, dan portal media informasi online.",
    "telephone": "+6282377823390",
    "sameAs": [
      "https://instagram.com/401xd",
      "https://401xd.com",
      "mailto:mycoding@401xd.com"
    ],
    "logo": {
      "@type": "ImageObject",
      "@id": "#LogoCorporation",
      "inLanguage": "ID",
      "url": "<?php echo $info['URL']; ?>/img/safelink/401XDGroup.png",
      "caption": "401XD Group Indonesia"
    },
    "image": {
      "@type": "ImageObject",
      "@id": "#ImageCorporation",
      "inLanguage": "ID",
      "url": "<?php echo $info['URL']; ?>/img/safelink/401XDGroupIndonesia.png",
      "caption": "401XD Group Indonesia"
    },
    "address": {
      "@type": "PostalAddress",
      "@id": "#PostalAddressCorporation",
      "streetAddress": "401XD Group, Jl. Sumbawa, Ulak Karang Utara, Kec. Padang Utara",
      "addressLocality": "Kota Padang",
      "addressRegion": "Sumatera Barat",
      "postalCode": "25133",
      "addressCountry": "Indonesia"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "<?php echo date('Y'); ?>"
    },
    "review": {
      "@type": "Review",
      "@id": "#ReviewCorporation",
      "name": "Review MC Project",
      "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
      "description": "Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "4.9",
        "worstRating": "1",
        "bestRating": "5"
      }
    }
  }
</script>