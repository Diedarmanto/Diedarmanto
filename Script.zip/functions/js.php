<!--Adblock Indicator Scroll-->
<script type='text/javascript'>
  //<![CDATA[
  function downloadJSAtOnload(){var e=document.createElement("script");e.src="https://cdn.jsdelivr.net/gh/adigunawanxd/pluginsgalaxymag@master/seosecretidnblockads.js",document.body.appendChild(e)}window.addEventListener?window.addEventListener("load",downloadJSAtOnload,!1):window.attachEvent?window.attachEvent("onload",downloadJSAtOnload):window.onload=downloadJSAtOnload;
  //]]>
</script>
<div class='progress-container'>
  <div class='progress-bar' id='progressbar'/>
</div>
<script type='text/javascript'>
  //<![CDATA[
  window.addEventListener('scroll', myFunction);
  function myFunction() {
    var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var scrolled = (winScroll / height) * 100;
    document.getElementById('progressbar').style.width = scrolled + '%';
  }
  //]]>
</script>