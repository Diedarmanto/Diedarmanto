<?php
    @$fullurl = ($_SERVER['PHP_SELF']);
    @$trimmed = trim($fullurl, ".php");
    @$canonical = rtrim($trimmed, '/' . '/?');
?>

<!--Viewport-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<!-- Search engines verification -->
<meta name="google-site-verification" content="">
<meta name="msvalidate.01" content="">
<meta name="yandex-verification" content="">
<meta name="norton-safeweb-site-verification" content="">

<!-- Social media verification-->
<meta name="p:domain_verify" content="">
<meta name="facebook-domain-verification" content="">
    
<!-- Canonical -->
<meta name="robots" content="all,index,follow">
<link rel="home" href="<?php echo $info['URL']; ?>">
<link rel="canonical" href="<?php echo $info['URL']; ?><?php echo $canonical ?>">

<!--Author-->
<meta name="author" content="MC Project">
<meta name="publisher" content="401XD Group">

<!--Location-->
<meta content="en" name="geo.region">
<meta content="x;x" name="geo.position">
<meta content="x,x" name="ICBM">
<link rel="alternate" href="<?php echo $info['URL']; ?><?php echo $canonical ?>" hreflang="x-default">

<!-- OG 2-->
<meta property="og:site_name" content="<?php echo $info['name']; ?>">
<meta property="og:url" content="<?php echo $info['URL']; ?><?php echo $canonical ?>">
<meta property="og:image" content="<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png">
<meta name="thumbnail" content="<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png">
<meta property="og:locale" content="en_US">
<meta property="og:locale:alternate" content="id_ID">

<meta property="fb:app_id" content="">
<meta property="pinterest-rich-pin" content="true">
<meta property="article:author" content="MC Project">
<meta property="og:rich_attachment" content="true">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">

<meta name="twitter:url" content="<?php echo $info['URL']; ?><?php echo $canonical ?>">
<meta name="twitter:site" content="<?php echo $info['name']; ?>">
<meta name="twitter:creator" content="<?php echo $info['name']; ?>">
<meta name="twitter:image" content="<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png">
<meta name="twitter:card" content="summary_large_image">
<meta itemprop="url" content="<?php echo $info['URL']; ?><?php echo $canonical ?>">
<meta itemprop="image" content="<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png">
<link rel="schema.DC" href="<?php echo $info['URL']; ?><?php echo $canonical ?>">
<link rel="schema.DCTERMS" href="<?php echo $info['URL']; ?>/tos">
<meta name="DC.creator" content="<?php echo $info['name']; ?>">
<meta name="DC.identifier" scheme="DCTERMS.URI" content="<?php echo $info['URL']; ?><?php echo $canonical ?>">
<meta name="DC.format" scheme="DCTERMS.IMT" content="text/html">
<meta name="DC.type" scheme="DCTERMS.DCMIType" content="text">
<meta name="DCTERMS.type" content="Services">
<meta name="DCTERMS.source" property="og:site_name" content="<?php echo $info['name']; ?>">
<meta name="DCTERMS.contributor" content="<?php echo $info['name']; ?>">
<meta name="DCTERMS.language" content="id-ID">