<!-- Webapp -->
<link rel="manifest" href="<?php echo $info['URL']; ?>/manifest.json">
<meta name="msapplication-starturl" content="<?php echo $info['URL']; ?>">
<meta name="start_url" content="<?php echo $info['URL']; ?>">
<meta name="application-name" content="<?php echo $info['name']; ?>">
<meta name="apple-mobile-web-app-title" content="<?php echo $info['name']; ?>">
<meta name="msapplication-tooltip" content="<?php echo $info['name']; ?>">
<meta name="theme-color" content="#0d47a1">
<meta name="background_color" content="#FFFFFF">
<meta name="msapplication-navbutton-color" content="#0d47a1">
<meta name="msapplication-TileColor" content="#0d47a1">
<meta name="apple-mobile-web-app-status-bar-style" content="#0d47a1">
<meta name="mssmarttagspreventparsing" content="true">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<link rel="shortcut icon" href="<?php echo $info['URL']; ?>/img/favicon.png" type="image/png">
<meta name="msapplication-TileImage" content="<?php echo $info['URL']; ?>/img/safelink/safelink-144.png">
<link rel="apple-touch-icon" href="<?php echo $info['URL']; ?>/img/safelink/safelink-180.png">
<link rel="icon" sizes="32x32" href="<?php echo $info['URL']; ?>/img/safelink/safelink-32.png">
<link rel="icon" sizes="48x48" href="<?php echo $info['URL']; ?>/img/safelink/safelink-48.png">
<link rel="icon" sizes="72x72" href="<?php echo $info['URL']; ?>/img/safelink/safelink-72.png">
<link rel="icon" sizes="96x96" href="<?php echo $info['URL']; ?>/img/safelink/safelink-96.png">
<link rel="icon" sizes="144x144" href="<?php echo $info['URL']; ?>/img/safelink/safelink-144.png">
<link rel="icon" sizes="168x168" href="<?php echo $info['URL']; ?>/img/safelink/safelink-168.png">
<link rel="icon" sizes="180x180" href="<?php echo $info['URL']; ?>/img/safelink/safelink-180.png">
<link rel="icon" sizes="192x192" href="<?php echo $info['URL']; ?>/img/safelink/safelink-192.png">
<link rel="icon" sizes="256x256" href="<?php echo $info['URL']; ?>/img/safelink/safelink-256.png">
<link rel="icon" sizes="512x512" href="<?php echo $info['URL']; ?>/img/safelink/safelink-512.png">

<!--resource-->
<link href="//www.youtube.com" rel="preconnect dns-prefetch">
<link href="//pagead2.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//googleads.g.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//ad.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//i.ytimg.com" rel="preconnect dns-prefetch">
<link href="//www.gstatic.com" rel="preconnect dns-prefetch">
<link href="//www.google.com" rel="preconnect dns-prefetch">
<link href="//tpc.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//www.google-analytics.com" rel="preconnect dns-prefetch">
<link href="//yt3.ggpht.com" rel="preconnect dns-prefetch">
<link href="//cdn.jsdelivr.net" rel="preconnect dns-prefetch">
<link href="//fonts.gstatic.com" rel="preconnect dns-prefetch">
<link href="//adservice.google.com" rel="preconnect dns-prefetch">
<link href="//ajax.cloudflare.com" rel="preconnect dns-prefetch">
<link href="//www.googletagmanager.com" rel="preconnect dns-prefetch">
<link href="//partner.googleadservices.com" rel="preconnect dns-prefetch">
<link href="//www.googletagservices.com" rel="preconnect dns-prefetch">
<link href="//static.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//www.recaptcha.net" rel="preconnect dns-prefetch">
<link href="//1.bp.blogspot.com" rel="preconnect dns-prefetch">
<link href="//2.bp.blogspot.com" rel="preconnect dns-prefetch">
<link href="//3.bp.blogspot.com" rel="preconnect dns-prefetch">
<link href="//4.bp.blogspot.com" rel="preconnect dns-prefetch">