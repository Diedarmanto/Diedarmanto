﻿<!DOCTYPE html>
<html lang="en-US">
<head>
    <!--OG 1-->
    <title>URL Created - <?php echo $info['name']; ?></title>
    <meta name="title" content="URL Created - <?php echo $info['name']; ?>">
    <meta name="description" content="URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="URL Created - <?php echo $info['name']; ?>">
    <meta property="og:type" content="article">
    <meta property="og:description" content="URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="URL Created - <?php echo $info['name']; ?>">
    <meta name="twitter:description" content="URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <?php
        include "og2.php";
        include "metawebapp.php";
    ?>
   <!-- Bootstrap core CSS -->
   <link href="../css/bootstrap.css" rel="stylesheet">
   <link href="../css/animate.css" rel="stylesheet">
   <!-- Custom CSS for the Template -->
   <link href="../css/style.css" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
   <style>
    a { color: inherit; }
   </style>
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>
    <?php
        include "css.php";
        include "googleanalytics.php";
        include "schema.php";
    ?>
    <!--WebPage-->
    <script type="application/ld+json">
    {"@context":"https://schema.org","@type":"WebPage","@id":"#WebPage","name":"URL Created <?php echo $info['name']; ?>","alternateName":"URL Created - <?php echo $info['name']; ?>","headline":"URL Created <?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?><?php echo $canonical ?>","description":"URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","disambiguatingDescription":"URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group","keywords":["shortlink","safelink","url shortener"],"genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],"image":{"@type":"ImageObject","@id":"#Image","inLanguage":"en-US","url":"<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png","caption":"URL Created <?php echo $info['name']; ?>"},"inLanguage":"en-US","sameAs":["https://www.facebook.com/mycodingxd","https://www.twitter.com/mycodingxd","https://www.instagram.com/mycodingxd","https://www.youtube.com/c/mycodingxd"],"potentialAction":{"@type":"SearchAction","target":"<?php echo $info['URL']; ?>/statics?q={search_term_string}","query-input":"required name=search_term_string"},"speakable":{"@type":"SpeakableSpecification","xpath":["/html/head/title","/html/head/meta[@name='description']/@content"]},"publisher":{"@id":"#Organization"},"sponsor":{"@id":"#Corporation"},"isPartOf":{"@id":"#WebSite"},"mainEntityOfPage":"true","isFamilyFriendly":"true","author":[{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},{"@id":"#Organization"}],"creator":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"accountablePerson":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"copyrightYear":"<?php echo date('Y'); ?>","copyrightHolder":{"@id":"#Corporation"}}
    </script>
    <!--BreadcrumbList-->
    <script type="application/ld+json">
      {"@context":"https://schema.org","@type":"BreadcrumbList","@id":"#BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"<?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?>","item":"<?php echo $info['URL']; ?>"},{"@type":"ListItem","position":2,"name":"URL Created <?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?><?php echo $canonical ?>","item":"<?php echo $info['URL']; ?><?php echo $canonical ?>"}]}
    </script>
    <!--ImageObject-->
    <script type="application/ld+json">
      {"@context":"https://schema.org","@type":"ImageObject","@id":"#ImageObject","name":"URL Created <?php echo $info['name']; ?>","alternateName":"URL Created - <?php echo $info['name']; ?>","headline":"URL Created <?php echo $info['name']; ?>","alternativeHeadline":"URL Created <?php echo $info['name']; ?>","description":"URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","disambiguatingDescription":"URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","abstract":"URL Created - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group","keywords":["shortlink","safelink","url shortener"],"genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],"caption":"URL Created <?php echo $info['name']; ?>","contentUrl":"https://seosecret.id/placeholder/1200x720/0d47a1/ffffff/<?php echo htmlspecialchars(str_ireplace('&', 'dan', strip_tags(str_replace('\\', '/', str_replace(' ', '+', 'URL Created'))))); ?>/webp","inLanguage":"en-US","license":"https://url.401xd.com/tos","acquireLicensePage":"<?php echo $info['URL']; ?><?php echo $canonical ?>","creditText":"<?php echo $info['name']; ?>","creator":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"copyrightNotice":"401XD Group","isBasedOnUrl":"<?php echo $info['URL']; ?><?php echo $canonical ?>"}
    </script>
</head>
<body>
    <h1 class="sr-only">URL Created - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">URL Created <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">URL Created</h3>
    <?php
    include "menu.php";
    ?>
    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "logo.php";
                include "darkmode.php";
                ?>
            </div>
        </div>
    </div>
    <div class="container animated fadeIn bodynew">
        <div class="row">
            <div class="col-lg-10 col-lg-offset-1">
                <div class="alert alert-dismissable alert-default text-center">
                    <h4 style="color: #707070;">URL shorted successfully </h4> 
                </div>
            </div>
        </div>
        <div class="row mt-20">
            <div class="col-lg-12">
                <div class="input-group">
                    <input id="urlbox" class="form-control cz-shorten-input" readonly name="url" value="<?php echo $created_link; ?>"  type="url">
                    <div class="input-group-btn">
                        <button class="btn btn-large btn-primary cz-shorten-btn" type="submit" id="copy-button">Copy!</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-30">
            <div class="col-lg-4 text-center">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title newsize" style="font-weight:bolder;">QR Code</h3>
                    </div>
                    <div class="panel-body">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?php echo $created_link; ?>&cht=qr&chl=<?php echo $created_link; ?>">
                    </div>
                </div>
            </div>
            <div class="col-lg-8 text-center">
                <div class="row">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title newsize" style="font-weight:bolder;">Share</h3>
                        </div>
                        <div class="panel-body">
                            <a target="_blank"  href="http://www.facebook.com/sharer.php?u=<?php echo $created_link; ?>"><i class="fab fa-facebook-f fa-3x fb anim "></i></a>
                            <a target="_blank"  href="https://twitter.com/share?url=<?php echo $created_link; ?>"><i class="fab fa-twitter fa-3x twit anim "></i></a>
                            <a target="_blank"  href="http://pinterest.com/pin/create/button/?url=<?php echo $created_link; ?>"><i class="fab fa-pinterest fa-3x pin anim"></i></a>

                        </div>
                    </div>
                </div>
                <!-- row -->
                <div class="row" style="margin-top: -4px;">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title newsize" style="font-weight:bolder;">Stats</h3>
                        </div>
                        <div class="panel-body">
                            <a href="<?php echo $info['URL'] . '/stats.php?id=' . $rand1; ?>"> <h3><?php echo $info['URL'] . '/stats.php?id=' . $rand1; ?></h3></a>
                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
        </div>
    </div>
    <!-- JavaScript -->
    <script src="../js/jquery-1.10.2.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script type="text/javascript" src="../js/jquery.zclip.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#copy-button").click(function () {
                $(this).html("Copied!");
                $("#urlbox").select();
                document.execCommand("copy");
            });
        });
    </script>
    <?php
        include "js.php";
    ?>
</body>
</html>