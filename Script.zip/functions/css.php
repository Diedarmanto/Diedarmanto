    <style type="text/css">
        /*adblock*/
        @keyframes fadeInDown{0%{opacity:0;transform:translateY(-20px)}100%{opacity:1;transform:translateY(0)}}
        @keyframes rubberBand{from{transform:scale3d(1,1,1)}30%{transform:scale3d(1.25,0.75,1)}40%{transform:scale3d(0.75,1.25,1)}50%{transform:scale3d(1.15,0.85,1)}65%{transform:scale3d(.95,1.05,1)}75%{transform:scale3d(1.05,.95,1)}to{transform:scale3d(1,1,1)}}
        /*seosecretidnadblock*/
        #seosecretidnadblock{background:rgba(0,0,0,0.65);position:fixed;margin:auto;left:0;right:0;top:0;bottom:0;overflow:auto;z-index:999999;animation:fadeInDown 1s}
        #seosecretidnadblock .header{margin:0 0 15px 0;color: #333;justify-content: center;}
        #seosecretidnadblock .inner{background:#CC3333;color:#F5F5F5;box-shadow:0 5px 20px rgba(0,0,0,0.1);text-align:center;width:600px;padding:30px;border-radius:5px;margin:7% auto 2% auto;animation:rubberBand 2s}
        #seosecretidnadblock button{padding:10px 20px;border:0;background:rgba(0,0,0,0.15);color:#F5F5F5;margin:10px 5px;cursor:pointer;transition:all .3s}
        #seosecretidnadblock button:hover{background:rgba(0,0,0,0.35);color:#fff;outline:none}
        #seosecretidnadblock button.active,#arlinablock button:hover.active{background:#F5F5F5;color:#333333;outline:none}
        #seosecretidnadblock .fixblock{background:#FFFFFF;text-align:center;color:#333333;padding:10px 0px;height:300px;overflow:auto;line-height:30px}
        #seosecretidnadblock .fixblock div{display:none}
        #seosecretidnadblock .fixblock div.active{display:block}
        #seosecretidnadblock ol{margin-left:0px}
        @media(max-width:768px){#seosecretidnadblock .inner{width:calc(100% - 30px);margin:10px auto;padding:15px}}
        /*Indicator Load*/
        .progress-container{width:100%;position:fixed;top:0;left:0;z-index:9999}.progress-bar{height:5px;background:#0D47A1;width:0%}
        /*Scroll Bar*/
        html{scrollbar-width:thin}
        html::-webkit-scrollbar{width:5px;background-color:#F5F5F5}
        html::-webkit-scrollbar-thumb{background-color:#0D47A1;border-radius:0px}
        .element{scrollbar-width:thin}
        .element::-webkit-scrollbar{width:5px;background-color:#F5F5F5}
        .element::-webkit-scrollbar-thumb{background-color:#0D47A1;border-radius:0px}
    </style>
    
    <!--Hyperlink-->
    <script type='text/javascript'>
      //<![CDATA[
      document.addEventListener('DOMContentLoaded', function () {
        var links = document.getElementsByTagName("a");
        var i;
        for (i = 0; i < links.length; i++) {
          if (location.hostname !== links[i].hostname) {
            links[i].rel = "nofollow noopener noreferrer";
          }
        }
      });
      //]]>
    </script>