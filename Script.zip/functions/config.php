<?php
// Start PHP
ob_start();
date_default_timezone_set("Asia/Jakarta");
if (!isset($_SESSION)) {
    ini_set('session.use_cookies', '1');
    ini_set('session.gc_maxlifetime', 86400);
    session_set_cookie_params(86400);
    session_start();
}
error_reporting(0);
ini_set('display_errors',0);
ini_set('log_errors',0);

$version = "1.1.1"; //app version