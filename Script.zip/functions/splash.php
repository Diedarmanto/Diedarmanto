<!DOCTYPE html>
<html lang="en-US">
<head>
    <!--OG 1-->
    <title>Redirecting - <?php echo $info['name']; ?></title>
    <meta name="title" content="Redirecting - <?php echo $info['name']; ?>">
    <meta name="description" content="Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="Redirecting - <?php echo $info['name']; ?>">
    <meta property="og:type" content="article">
    <meta property="og:description" content="Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="Redirecting - <?php echo $info['name']; ?>">
    <meta name="twitter:description" content="Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta itemprop="title" content="Redirecting - <?php echo $info['name']; ?>">
    <meta itemprop="name" content="Redirecting - <?php echo $info['name']; ?>">
    <meta itemprop="description" content="Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DCTERMS.abstract" content="Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DC.title" lang="id-ID" content="Redirecting - <?php echo $info['name']; ?>">
    
    <?php
        include "og2.php";
        include "metawebapp.php";
    ?>

   <!-- Bootstrap core CSS -->
   <link href="../css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
   <link href="../css/animate.css?<?php echo $version; ?>" rel="stylesheet">
   <!-- Custom CSS for the Template -->
   <link href="../css/style.css?<?php echo $version; ?>" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
   <link href="../font/css/font-awesome.min.css?<?php echo $version; ?>" rel="stylesheet" type="text/css" />
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>

    <?php
        include "css.php";
        include "googleanalytics.php";
        include "schema.php";
    ?>

    <!--WebPage-->
    <script type="application/ld+json">
        {
          "@context": "http://schema.org",
          "@type": "WebPage",
          "@id": "#WebPage",
          "name": "Redirecting <?php echo $info['name']; ?>",
          "alternateName": "Redirecting - <?php echo $info['name']; ?>",
          "headline": "Redirecting <?php echo $info['name']; ?>",
          "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
          "description": "Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
          "disambiguatingDescription": "Redirecting - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
          "keywords":["shortlink","safelink","url shortener"],
          "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
          "image": {
              "@type": "ImageObject",
              "@id": "#Image",
              "inLanguage": "id-ID",
              "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
              "caption": "Redirecting <?php echo $info['name']; ?>"
          },
          "inLanguage": "id-ID",
          "sameAs": [
              "https://www.facebook.com/mycodingxd",
              "https://www.twitter.com/mycodingxd",
              "https://www.instagram.com/mycodingxd",
              "https://www.youtube.com/c/mycodingxd"
          ],
          "potentialAction": {
              "@type": "SearchAction",  
              "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
              "query-input": "required name=search_term_string"
          },
          "speakable": {
            "@type": "SpeakableSpecification",
            "xpath": [
              "/html/head/title",
              "/html/head/meta[@name='description']/@content"
            ]
          },
          "publisher": {"@id": "#Organization"},
          "sponsor": {"@id": "#Corporation"},
          "isPartOf": {"@id": "#WebSite"},
          "mainEntityOfPage": "true",
          "isFamilyFriendly": "true",
          "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
          "creator": "<?php echo $info['name']; ?>",
          "accountablePerson": "<?php echo $info['name']; ?>",
          "copyrightYear": "<?php echo date('Y'); ?>",
          "copyrightHolder": "<?php echo $info['name']; ?>"
        }
    </script>

</head>
<body>

    <h1 class="sr-only">Redirecting - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">Redirecting <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">Redirecting</h3>

    <?php
    include "menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "logo.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated flipInY bodynew">

        <div class="row">
          <div class="col-lg-12 text-center">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title newsize" style="font-weight:bolder;"></div>
                </div>
                <div class="panel-body" style="padding:0;margin:0;">
                    <?php echo '' . $ads_info['ad3'] . ''; ?>
                </div>
            </div>
          </div>
        </div>

        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 style="color: #707070;"> <p>You will be redirected <span id="cz"> in <span id="counter">10</span> second(s).</span></p></h2>
            </div>
        </div>

        <div class="row mt-30">
          <div class="col-lg-12 text-center">
            <div class="panel panel-primary">
                <div class="panel-body" style="padding:0;margin:0;">
                    <?php echo '' . $ads_info['ad4'] . ''; ?>
                </div>
                <div class="panel-heading">
                    <div class="panel-title newsize" style="font-weight:bolder;"></div>
                </div>
            </div>
          </div>
        </div>

    </div>
    <!-- JavaScript -->
    <script src="../js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
    <script src="../js/bootstrap.js?<?php echo $version; ?>"></script>

    <script type="text/javascript">
        function countdown() {
            var i = document.getElementById('counter');
            if (parseInt(i.innerHTML) <= 0) {
                document.getElementById("cz").innerHTML = "Now !";
                location.href = '<?php echo str_replace("'", "",$url); ?>';
            }
            i.innerHTML = parseInt(i.innerHTML) - 1;
        }
        setInterval(function() {
            countdown();
        }, 1000); //1000 = 10 detik
    </script>

    <?php
        include "js.php";
    ?>

</body>
</html>