<?php

if ($info['redirect'] == 1) {
    include "splash.php";
} else {
    include "basic_redirect.php";
}
?>