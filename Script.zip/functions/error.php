﻿<?php

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);

$ads = $db->query("SELECT * FROM ads");
$ads_info = $db->fetch_array($ads);
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
   <base href="<?php echo $info['URL']; ?>/" />
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="description" content="">
   <meta name="author" content="">

   <title>Error - <?php echo $info['name']; ?></title>
   <link rel="shortcut icon" href="<?php echo $info['URL']; ?>/img/favicon.png?<?php echo $version; ?>" type="image/x-icon">

   <!-- Bootstrap core CSS -->
   <link href="../css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
   <link href="../css/animate.css?<?php echo $version; ?>" rel="stylesheet">

   <!-- Custom CSS for the Template -->
   <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
   <link href="../css/style.css?<?php echo $version; ?>" rel="stylesheet">
   <style>
    <?php echo $info['cstm-style']; ?>
</style>
</head>

<body>

    <?php
    include "menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "logo.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated shake bodynew">

        <div class="row">
            <div class="col-lg-10 col-lg-offset-1 mt-20">
                <div class="alert alert-dismissable alert-danger text-center">
                    <h3  style="color: #707070;">Opps! <?php echo $error_msg; ?></h3> 
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10 col-md-offset-1 mt-20 mb-20" style="text-align: center;">
                <?php echo '' . $ads_info['ad2'] . ''; ?>
            </div>
        </div>			

    </div>
    <!-- JavaScript -->
    <script src="../js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
    <script src="../js/bootstrap.js?<?php echo $version; ?>"></script>

</body>

</html>
