﻿<!DOCTYPE html>
<html lang="en-US">
<head>
  <!--OG 1-->
  <title>Thank You - <?php echo $info['name']; ?></title>
  <meta name="title" content="Thank You - <?php echo $info['name']; ?>">
  <meta name="description" content="Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="keywords" content="shortlink, safelink, url shortener">
  <meta property="og:title" content="Thank You - <?php echo $info['name']; ?>">
  <meta property="og:type" content="article">
  <meta property="og:description" content="Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="twitter:title" content="Thank You - <?php echo $info['name']; ?>">
  <meta name="twitter:description" content="Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta itemprop="title" content="Thank You - <?php echo $info['name']; ?>">
  <meta itemprop="name" content="Thank You - <?php echo $info['name']; ?>">
  <meta itemprop="description" content="Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="DCTERMS.abstract" content="Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="DC.title" lang="id-ID" content="Thank You - <?php echo $info['name']; ?>">
  
  <?php
      include "og2.php";
      include "metawebapp.php";
  ?>

   <!-- Bootstrap core CSS -->
   <link href="../css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
   <link href="../css/animate.css?<?php echo $version; ?>" rel="stylesheet">
   <!-- Custom CSS for the Template -->
   <link href="../css/style.css?<?php echo $version; ?>" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
   <link href="../font/css/font-awesome.min.css?<?php echo $version; ?>" rel="stylesheet" type="text/css" />
   <style>
    a { color: inherit; }
    </style>
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>

    <?php
        include "css.php";
        include "googleanalytics.php";
        include "schema.php";
    ?>

    <!--WebPage-->
    <script type="application/ld+json">
        {
          "@context": "http://schema.org",
          "@type": "WebPage",
          "@id": "#WebPage",
          "name": "Thank You <?php echo $info['name']; ?>",
          "alternateName": "Thank You - <?php echo $info['name']; ?>",
          "headline": "Thank You <?php echo $info['name']; ?>",
          "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
          "description": "Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
          "disambiguatingDescription": "Thank You - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
          "keywords":["shortlink","safelink","url shortener"],
          "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
          "image": {
              "@type": "ImageObject",
              "@id": "#Image",
              "inLanguage": "id-ID",
              "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
              "caption": "Thank You <?php echo $info['name']; ?>"
          },
          "inLanguage": "id-ID",
          "sameAs": [
              "https://www.facebook.com/mycodingxd",
              "https://www.twitter.com/mycodingxd",
              "https://www.instagram.com/mycodingxd",
              "https://www.youtube.com/c/mycodingxd"
          ],
          "potentialAction": {
              "@type": "SearchAction",  
              "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
              "query-input": "required name=search_term_string"
          },
          "speakable": {
            "@type": "SpeakableSpecification",
            "xpath": [
              "/html/head/title",
              "/html/head/meta[@name='description']/@content"
            ]
          },
          "publisher": {"@id": "#Organization"},
          "sponsor": {"@id": "#Corporation"},
          "isPartOf": {"@id": "#WebSite"},
          "mainEntityOfPage": "true",
          "isFamilyFriendly": "true",
          "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
          "creator": "<?php echo $info['name']; ?>",
          "accountablePerson": "<?php echo $info['name']; ?>",
          "copyrightYear": "<?php echo date('Y'); ?>",
          "copyrightHolder": "<?php echo $info['name']; ?>"
        }
    </script>

</head>
<body>

    <h1 class="sr-only">Thank You - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">Thank You <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">Thank You</h3>
    
    <?php
    include "menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "logo.php";
                ?>
            </div>
        </div>
    </div>
    <div class="container animated tada bodynew">
        <div class="row mt-20">
            <div class="modal-dialog">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h4 class="panel-title" id="contactLabel"><span class="fa fa-info-circle"></span> Thank You</h4>
                    </div>
                    <form method="post" action="?op=contact" accept-charset="utf-8">
                        <div class="modal-body">
                            <div class="row">
                                <h3 class="text-info" style="text-align: center"> We have received your message </h3> 
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
        <!-- JavaScript -->
        <script src="../js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
        <script src="../js/bootstrap.js?<?php echo $version; ?>"></script>
        <script type="text/javascript" src="../js/jquery.zclip.min.js?<?php echo $version; ?>"></script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#copy-button").zclip({
                    path: "js/ZeroClipboard.swf",
                    copy: function() {
                        return $('#urlbox').val();
                    },
                    beforeCopy: function() {
                    },
                    afterCopy: function() {
                        $("#copy-button").html('Copied');
                    }
                });
            });
        </script>

        <?php
            include "js.php";
        ?>

    </body>
    </html>
