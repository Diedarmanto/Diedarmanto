<!DOCTYPE html>
<html lang="en-US">
<head>
    <!--OG 1-->
    <title>Protected Link - <?php echo $info['name']; ?></title>
    <meta name="title" content="Protected Link - <?php echo $info['name']; ?>">
    <meta name="description" content="Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="Protected Link - <?php echo $info['name']; ?>">
    <meta property="og:type" content="article">
    <meta property="og:description" content="Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="Protected Link - <?php echo $info['name']; ?>">
    <meta name="twitter:description" content="Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta itemprop="title" content="Protected Link - <?php echo $info['name']; ?>">
    <meta itemprop="name" content="Protected Link - <?php echo $info['name']; ?>">
    <meta itemprop="description" content="Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DCTERMS.abstract" content="Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DC.title" lang="id-ID" content="Protected Link - <?php echo $info['name']; ?>">
    
    <?php
        include "og2.php";
        include "metawebapp.php";
    ?>

    <link href="../font/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>

    <?php
        include "css.php";
        include "googleanalytics.php";
        include "schema.php";
    ?>

    <!--WebPage-->
    <script type="application/ld+json">
        {
          "@context": "http://schema.org",
          "@type": "WebPage",
          "@id": "#WebPage",
          "name": "Protected Link <?php echo $info['name']; ?>",
          "alternateName": "Protected Link - <?php echo $info['name']; ?>",
          "headline": "Protected Link <?php echo $info['name']; ?>",
          "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
          "description": "Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
          "disambiguatingDescription": "Protected Link - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
          "keywords":["shortlink","safelink","url shortener"],
          "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
          "image": {
              "@type": "ImageObject",
              "@id": "#Image",
              "inLanguage": "id-ID",
              "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
              "caption": "Protected Link <?php echo $info['name']; ?>"
          },
          "inLanguage": "id-ID",
          "sameAs": [
              "https://www.facebook.com/mycodingxd",
              "https://www.twitter.com/mycodingxd",
              "https://www.instagram.com/mycodingxd",
              "https://www.youtube.com/c/mycodingxd"
          ],
          "potentialAction": {
              "@type": "SearchAction",  
              "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
              "query-input": "required name=search_term_string"
          },
          "speakable": {
            "@type": "SpeakableSpecification",
            "xpath": [
              "/html/head/title",
              "/html/head/meta[@name='description']/@content"
            ]
          },
          "publisher": {"@id": "#Organization"},
          "sponsor": {"@id": "#Corporation"},
          "isPartOf": {"@id": "#WebSite"},
          "mainEntityOfPage": "true",
          "isFamilyFriendly": "true",
          "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
          "creator": "<?php echo $info['name']; ?>",
          "accountablePerson": "<?php echo $info['name']; ?>",
          "copyrightYear": "<?php echo date('Y'); ?>",
          "copyrightHolder": "<?php echo $info['name']; ?>"
        }
    </script>

</head>
<body>

    <h1 class="sr-only">Protected Link - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">Protected Link <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">Protected Link</h3>

    <?php 
    include "menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "logo.php";
                ?>
            </div>
        </div>
    </div>
    
    <div class="container animated fadeIn bodynew">
        <div class="row">
            <div class="modal-dialog">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title" id="contactLabel"><span class="fa fa-lock"></span> Protected Link</h4>
                    </div>
                    <div class="modal-body">
                        <form name="form" method="post" action="<?php echo $shr; ?>">
                            <div class="form-group" >
                                <div class="input-group">
                                    <input type="password" name="txtpass" placeholder="Please Enter Password" class="form-control">
                                    <span class="input-group-addon">
                                        <i class="fa fa-lock form-control-feedback"></i>
                                    </span>
                                </div>
                            </div> 
                            <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info ">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <?php
        include "js.php";
    ?>

</body>
</html>



