﻿<?php
include "functions/database.php";
include "functions/count.php";
include "admin/functions/time.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);

$ads = $db->query("SELECT * FROM ads");
$ads_info = $db->fetch_array($ads);
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <!--OG 1-->
    <title>Statistics - <?php echo $info['name']; ?></title>
    <meta name="title" content="Statistics - <?php echo $info['name']; ?>">
    <meta name="description" content="Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="keywords" content="shortlink, safelink, url shortener">
    <meta property="og:title" content="Statistics - <?php echo $info['name']; ?>">
    <meta property="og:type" content="article">
    <meta property="og:description" content="Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="twitter:title" content="Statistics - <?php echo $info['name']; ?>">
    <meta name="twitter:description" content="Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta itemprop="title" content="Statistics - <?php echo $info['name']; ?>">
    <meta itemprop="name" content="Statistics - <?php echo $info['name']; ?>">
    <meta itemprop="description" content="Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DCTERMS.abstract" content="Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
    <meta name="DC.title" lang="id-ID" content="Statistics - <?php echo $info['name']; ?>">
    
    <?php
    include "functions/og2.php";
    include "functions/metawebapp.php";
    ?>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="css/animate.css?<?php echo $version; ?>" rel="stylesheet">
    <!-- Custom CSS for the Template -->
    <link href="css/style.css?<?php echo $version; ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <style>
        .nav-tabs > li, .nav-pills > li {
            float:none;
            display:inline-block;
        }
        .nav-tabs {
            text-align:center;
        }
    </style>
    <style>
        <?php echo $info['cstm-style']; ?>
    </style>

    <?php
    include "functions/css.php";
    include "functions/googleanalytics.php";
    include "functions/schema.php";
    ?>

    <!--WebPage-->
    <script type="application/ld+json">
        {
          "@context": "http://schema.org",
          "@type": "WebPage",
          "@id": "#WebPage",
          "name": "Statistics <?php echo $info['name']; ?>",
          "alternateName": "Statistics - <?php echo $info['name']; ?>",
          "headline": "Statistics <?php echo $info['name']; ?>",
          "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
          "description": "Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
          "disambiguatingDescription": "Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
          "keywords":["shortlink","safelink","url shortener"],
          "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
          "image": {
              "@type": "ImageObject",
              "@id": "#Image",
              "inLanguage": "id-ID",
              "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
              "caption": "Statistics <?php echo $info['name']; ?>"
          },
          "inLanguage": "id-ID",
          "sameAs": [
              "https://www.facebook.com/mycodingxd",
              "https://www.twitter.com/mycodingxd",
              "https://www.instagram.com/mycodingxd",
              "https://www.youtube.com/c/mycodingxd"
          ],
          "potentialAction": {
              "@type": "SearchAction",  
              "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
              "query-input": "required name=search_term_string"
          },
          "speakable": {
            "@type": "SpeakableSpecification",
            "xpath": [
              "/html/head/title",
              "/html/head/meta[@name='description']/@content"
          ]
        },
        "publisher": {"@id": "#Organization"},
        "sponsor": {"@id": "#Corporation"},
        "isPartOf": {"@id": "#WebSite"},
        "mainEntityOfPage": "true",
        "isFamilyFriendly": "true",
        "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
        "creator": "<?php echo $info['name']; ?>",
        "accountablePerson": "<?php echo $info['name']; ?>",
        "copyrightYear": "<?php echo date('Y'); ?>",
        "copyrightHolder": "<?php echo $info['name']; ?>"
    }
</script>

</head>

<body>

    <h1 class="sr-only">Statistics - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">Statistics <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">Statistics</h3>

    <?php
    include "functions/menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "functions/logo.php";
                include "functions/darkmode.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated fadeIn bodynew">
        <div class="col-lg-8 col-lg-offset-2 mt-20">
            <ul class="nav nav-tabs statics-tabs">
                <li class="active"><a href="#new" data-toggle="tab">New</a></li>
                <li class=""><a href="#pop" data-toggle="tab">Popular</a></li>
                <li class=""><a href="#rec" data-toggle="tab">Recently</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
                <div class="tab-pane fade active in" id="new" >
                    <div class="row" style="margin-top:-10px">
                        <div class="table-responsive">
                            <table id="file" class="statics table table-bordered table-striped table-hover">

                                <?php
                                $result = $db->query("SELECT * FROM links WHERE pass = '' ORDER BY date DESC LIMIT 10 ");
                                ?>
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <th>Link</th>
                                        <th>Created</th>
                                        <th>Stats</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while ($row = $db->fetch_array($result)) {
                                        $count01 = mb_strlen( $row['URL']);
                                        if($count01 > 50){
                                            $myurl =  substr($row['URL'],0,50)."...";
                                        } else {
                                            $myurl = $row['URL'];
                                        }
                                        ?>

                                        <tr class="record">
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $myurl; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $row['link']; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td><?php echo time_ago($row['date']); ?></td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/stats.php?id=' . $row['link']; ?>" target="_blank">
                                                    <div class="fa fa-signal">
                                                        Stats
                                                    </div>
                                                </a>
                                            </td>
                                        </tr>

                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="pop">
                    <div class="row" style="margin-top:-10px">
                        <div class="table-responsive">
                            <table id="file" class="statics table table-bordered table-striped table-hover">

                                <?php
                                $result = $db->query("SELECT * FROM links WHERE pass = '' ORDER BY hits DESC LIMIT 10 ");
                                ?>
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <th>Link</th>
                                        <th>Created</th>
                                        <th>Stats</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while ($row = $db->fetch_array($result)) {
                                        $count01 = mb_strlen( $row['URL']);
                                        if($count01 > 50){
                                            $myurl =  substr($row['URL'],0,50)."...";
                                        } else {
                                            $myurl = $row['URL'];
                                        }
                                        ?>

                                        <tr class="record">
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $myurl; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $row['link']; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td><?php echo time_ago($row['date']); ?></td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/stats.php?id=' . $row['link']; ?>" target="_blank">
                                                    <div class="fa fa-signal">
                                                        Stats
                                                    </div>
                                                </a>
                                            </td>
                                        </tr>

                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="rec">
                    <div class="row" style="margin-top:-10px">
                        <div class="table-responsive">
                            <table id="file" class="statics table table-bordered table-striped table-hover">

                                <?php
                                $result = $db->query("SELECT * FROM links WHERE pass = '' ORDER BY last_visit DESC LIMIT 10 ");
                                ?>
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <th>Link</th>
                                        <th>Created</th>
                                        <th>Stats</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while ($row = $db->fetch_array($result)) {
                                        $count01 = mb_strlen( $row['URL']);
                                        if($count01 > 50){
                                            $myurl =  substr($row['URL'],0,50)."...";
                                        } else {
                                            $myurl = $row['URL'];
                                        }

                                        ?>

                                        <tr class="record">
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $myurl; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/' . $row['link']; ?>" target="_blank">
                                                    <div>
                                                        <?php echo $row['link']; ?>
                                                    </div>
                                                </a>
                                            </td>
                                            <td><?php echo time_ago($row['date']); ?></td>
                                            <td>
                                                <a href="<?php echo $info['URL'] . '/stats.php?id=' . $row['link'];$db->close_connection(); ?>" target="_blank">
                                                    <div  class="fa fa-signal">
                                                        Stats
                                                    </div>
                                                </a>
                                            </td>
                                        </tr>

                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
    <script src="js/bootstrap.js?<?php echo $version; ?>"></script>

    <?php
    include "functions/js.php";
    ?>

</body>
</html>
