﻿<?php
include "functions/database.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
  <!--OG 1-->
  <title>About - <?php echo $info['name']; ?></title>
  <meta name="title" content="About - <?php echo $info['name']; ?>">
  <meta name="description" content="About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="keywords" content="shortlink, safelink, url shortener">
  <meta property="og:title" content="About - <?php echo $info['name']; ?>">
  <meta property="og:type" content="article">
  <meta property="og:description" content="About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="twitter:title" content="About - <?php echo $info['name']; ?>">
  <meta name="twitter:description" content="About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta itemprop="title" content="About - <?php echo $info['name']; ?>">
  <meta itemprop="name" content="About - <?php echo $info['name']; ?>">
  <meta itemprop="description" content="About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="DCTERMS.abstract" content="About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
  <meta name="DC.title" lang="id-ID" content="About - <?php echo $info['name']; ?>">

  <?php
      include "functions/og2.php";
      include "functions/metawebapp.php";
  ?>

  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.css?<?php echo $version; ?>" rel="stylesheet">
  <!-- Custom CSS for the Template -->
  <link href="css/style.css?<?php echo $version; ?>" rel="stylesheet">
  <link href="css/animate.css?<?php echo $version; ?>" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
  <style>
    <?php echo $info['cstm-style']; ?>
  </style>

  <?php
      include "functions/css.php";
      include "functions/googleanalytics.php";
      include "functions/schema.php";
  ?>

  <!--NewsArticle-->
  <script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "NewsArticle",
        "@id": "#NewsArticle",
        "name": "About <?php echo $info['name']; ?>",
        "alternateName": "About - <?php echo $info['name']; ?>",
        "headline": "About <?php echo $info['name']; ?>",
        "url": "<?php echo $info['URL']; ?><?php echo $canonical ?>",
        "description": "About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.",
        "disambiguatingDescription": "About - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group",
        "keywords":["shortlink","safelink","url shortener"],
        "genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],
        "image": {
            "@type": "ImageObject",
            "@id": "#Image",
            "inLanguage": "id-ID",
            "url": "<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png",
            "caption": "About <?php echo $info['name']; ?>"
        },
        "inLanguage": "id-ID",
        "sameAs": [
            "https://www.facebook.com/mycodingxd",
            "https://www.twitter.com/mycodingxd",
            "https://www.instagram.com/mycodingxd",
            "https://www.youtube.com/c/mycodingxd"
        ],
        "potentialAction": {
            "@type": "SearchAction",  
            "target": "<?php echo $info['URL']; ?>/statics?q={search_term_string}",
            "query-input": "required name=search_term_string"
        },
        "speakable": {
          "@type": "SpeakableSpecification",
          "xpath": [
            "/html/head/title",
            "/html/head/meta[@name='description']/@content"
          ]
        },
        "publisher": {"@id": "#Organization"},
        "sponsor": {"@id": "#Corporation"},
        "isPartOf": {"@id": "#WebSite"},
        "mainEntityOfPage": "true",
        "isFamilyFriendly": "true",
        "author": { "@type": "Person", "name": "MC Project", "url": "<?php echo $info['URL']; ?>" },
        "creator": "<?php echo $info['name']; ?>",
        "accountablePerson": "<?php echo $info['name']; ?>",
        "copyrightYear": "<?php echo date('Y'); ?>",
        "copyrightHolder": "<?php echo $info['name']; ?>"
      }
  </script>

</head>
<body>

    <h1 class="sr-only">About - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">About <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">About</h3>

    <?php
    include "functions/menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "functions/logo.php";
                include "functions/darkmode.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated fadeIn bodynew">
        <div class="row">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="myModalLabel">About Us</h2>
                    </div>
                    <div class="modal-body" style="min-height:10%; max-height:450px; overflow-y:scroll; overflow-x:none; position:relative;">
                      
                      <p>URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a panel from a long link. The site algorithm encodes and / or assigns to a table in a database the id of the short link. When that link receives a visit, the shortcut site, sends the visitor to the long link. This allows shorter destination URLs to be used, as well as camouflaging and adding functionality.</p>
                      <p></p>
                      <h3>What advantages do they have?</h3>
                      <p>Besides the mentioned saving of space by characters, useful in sites like Twitter, there are other advantages of using these shortened links: You can know the visits and statistics of the links. It is more elegant to look at.</p>
                      <p></p>
                      <h2>All about URL Safelink</h2>
                      <p>URL Safelink is a completely free tool where you can create short links. Protect your devices with a secure link, to avoid viruses, malware, thief, etc.</p>
                      <p></p>
                      <h3>Our Team</h3>
                      <p>In the heart of Asian a team of young internet enthusiasts came together to create a product that will give you a better way to earn money online. We've created a link shortener connected with advertising network so now you get paid when you shorten a link and make someone click on it.</p>

                      <p>Powered by <a href="https://mycoding.id">MC Project</a> </p>

                    </div>

                </div><!-- /.modal-content -->
            </div>
        </div>

    </div>
    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js?<?php echo $version; ?>"></script>
    <script src="js/bootstrap.js?<?php echo $version; ?>"></script>

    <?php
        include "functions/js.php";
    ?>

</body>
</html>