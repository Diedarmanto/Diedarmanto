﻿<?php
include "functions/database.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);
?>

<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>404 - Page not found</title>
        <link rel="shortcut icon" href="<?php echo $info['URL']; ?>/img/favicon.png?<?php echo $version; ?>" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            body {
                text-align: center;
                font-family: Nunito;
                padding-top: 200px;
            }
        </style>
    </head>
    <body>
        <h2>Error: 404</h2><b>Page not found</b>
        <br/>Sorry, we couldn't find anything at the url you entered. The page may have been previously existed but is no longer active.
        <br/>
        <a href="<?php echo $info['URL']; ?>"><b>HOME</b></a>
    </body>
</html>