﻿<?php
include "functions/database.php";
include "admin/functions/time.php";
$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);
$shr = $db->escape_value($_GET['id']);
$sql = $db->query("SELECT URL, date, hits, id, pass, last_visit FROM links WHERE BINARY link = '$shr'");
$sql = $db->fetch_array($sql);
$url = $sql["URL"];
$date = $sql["date"];
$hits = $sql["hits"];
$id = $sql["id"];
$pass = $sql["pass"];
$last_visit = $sql["last_visit"];
if ($url == '') {
    $error_msg = "Link you followed is not found";
    include "functions/error.php"; //error page
    $db->close_connection();
    exit;
} else {
    $myweb = $info['URL'];
    $created_link = $myweb . '/' . $shr;
    ?>
    <!DOCTYPE html>
    <html lang="en-US">
    <head>
        <!--OG 1-->
        <title>URL Statistics - <?php echo $info['name']; ?></title>
        <meta name="title" content="URL Statistics - <?php echo $info['name']; ?>">
        <meta name="description" content="URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
        <meta name="keywords" content="shortlink, safelink, url shortener">
        <meta property="og:title" content="URL Statistics - <?php echo $info['name']; ?>">
        <meta property="og:type" content="article">
        <meta property="og:description" content="URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
        <meta name="twitter:title" content="URL Statistics - <?php echo $info['name']; ?>">
        <meta name="twitter:description" content="URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.">
        <?php
        include "functions/og2.php";
        include "functions/metawebapp.php";
        ?>
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS for the Template -->
        <link href="css/style.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
        <style>
            .nav-tabs > li, .nav-pills > li {
                float:none;
                display:inline-block;
            }
            .nav-tabs {
                text-align:center;
            }
        </style>
        <style>
            <?php echo $info['cstm-style']; ?>
        </style>

        <?php
        include "functions/css.php";
        include "functions/googleanalytics.php";
        include "functions/schema.php";
        ?>

        <!--WebPage-->
        <script type="application/ld+json">
            {"@context":"https://schema.org","@type":"WebPage","@id":"#WebPage","name":"URL Statistics <?php echo $info['name']; ?>","alternateName":"URL Statistics - <?php echo $info['name']; ?>","headline":"URL Statistics <?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?><?php echo $canonical ?>","description":"URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","disambiguatingDescription":"URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group","keywords":["shortlink","safelink","url shortener"],"genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],"image":{"@type":"ImageObject","@id":"#Image","inLanguage":"en-US","url":"<?php echo $info['URL']; ?>/img/safelink/logo-safelink.png","caption":"URL Statistics <?php echo $info['name']; ?>"},"inLanguage":"en-US","sameAs":["https://www.facebook.com/mycodingxd","https://www.twitter.com/mycodingxd","https://www.instagram.com/mycodingxd","https://www.youtube.com/c/mycodingxd"],"potentialAction":{"@type":"SearchAction","target":"<?php echo $info['URL']; ?>/statics?q={search_term_string}","query-input":"required name=search_term_string"},"speakable":{"@type":"SpeakableSpecification","xpath":["/html/head/title","/html/head/meta[@name='description']/@content"]},"publisher":{"@id":"#Organization"},"sponsor":{"@id":"#Corporation"},"isPartOf":{"@id":"#WebSite"},"mainEntityOfPage":"true","isFamilyFriendly":"true","author":[{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},{"@id":"#Organization"}],"creator":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"accountablePerson":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"copyrightYear":"<?php echo date('Y'); ?>","copyrightHolder":{"@id":"#Corporation"}}
        </script>
        <!--BreadcrumbList-->
        <script type="application/ld+json">
            {"@context":"https://schema.org","@type":"BreadcrumbList","@id":"#BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"<?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?>","item":"<?php echo $info['URL']; ?>"},{"@type":"ListItem","position":2,"name":"URL Statistics <?php echo $info['name']; ?>","url":"<?php echo $info['URL']; ?><?php echo $canonical ?>","item":"<?php echo $info['URL']; ?><?php echo $canonical ?>"}]}
        </script>
        <!--ImageObject-->
        <script type="application/ld+json">
          {"@context":"https://schema.org","@type":"ImageObject","@id":"#ImageObject","name":"URL Statistics <?php echo $info['name']; ?>","alternateName":"URL Statistics - <?php echo $info['name']; ?>","headline":"URL Statistics <?php echo $info['name']; ?>","alternativeHeadline":"URL Statistics <?php echo $info['name']; ?>","description":"URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","disambiguatingDescription":"URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link.","abstract":"URL Statistics - <?php echo $info['name']; ?>. Links Shortener with QR Code and Statistics. URL Safelink are simple tools that generate redirects from a generally short url to a longer one. Users can create these redirects from a long link. 401XD Group","keywords":["shortlink","safelink","url shortener"],"genre":["Tool","Social","Tools","Software","Shortener","Platform","Application","Website"],"caption":"URL Statistics <?php echo $info['name']; ?>","contentUrl":"https://seosecret.id/placeholder/1200x720/0d47a1/ffffff/<?php echo htmlspecialchars(str_ireplace('&', 'dan', strip_tags(str_replace('\\', '/', str_replace(' ', '+', 'URL Statistics'))))); ?>/webp","inLanguage":"en-US","license":"https://url.401xd.com/tos","acquireLicensePage":"<?php echo $info['URL']; ?><?php echo $canonical ?>","creditText":"<?php echo $info['name']; ?>","creator":{"@type":"Person","name":"Adi Gunawan","honorificSuffix":"S.Kom., M.Kom.","url":"https://adigunawan.id/","sameAs":["https://orcid.org/0000-0002-5954-8068","https://www.researchgate.net/profile/Adi-Gunawan-3","https://scholar.google.com/citations?user=mDVQUgQAAAAJ","https://independent.academia.edu/AdiGunawanXD","https://www.facebook.com/AdigunawanXD","https://www.instagram.com/AdiGunawanXD"]},"copyrightNotice":"401XD Group","isBasedOnUrl":"<?php echo $info['URL']; ?><?php echo $canonical ?>"}
      </script>
  </head>
  <body>

    <h1 class="sr-only">URL Statistics - <?php echo $info['name']; ?></h1>
    <h2 class="sr-only">URL Statistics <?php echo $info['name']; ?></h2>
    <h3 class="sr-only">URL Stats</h3>

    <?php
    include "functions/menu.php";
    ?>

    <div class="container logonew">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                include "functions/logo.php";
                include "functions/darkmode.php";
                ?>
            </div>
        </div>
    </div>

    <div class="container animated fadeIn bodynew">
        <div class="col-lg-10 col-lg-offset-1">
            <div class="input-group">
                <input id="urlbox" class="form-control Url-field" name="url" value="<?php echo $created_link; ?>" type="url" >
                <div class="input-group-btn">
                    <button class="btn btn-small btn-success Copy-btn col-lg-pull-12" type="copy" id="copy-button">Copy</button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-5 QR rounded flex-col">
                <div class="col-lg-12"><h2 class="text-center"> QR Code</h2></div>
                <div class="col-lg-12"><img alt="QR Code" src="https://api.qrserver.com/v1/create-qr-code/?data=<?php echo $created_link; ?>&cht=qr&chl=<?php echo $created_link; ?>" class="size center-block"/></div>
                <div class="col-lg-12  text-center">
                    <a target="_blank"  href="http://www.facebook.com/sharer.php?u=<?php echo $created_link; ?>"><i class="fab fa-facebook-f fa-3x fb anim "></i></a>
                    <a target="_blank"  href="https://twitter.com/share?url=<?php echo $created_link; ?>"><i class="fab fa-twitter fa-3x twit anim "></i></a>
                    <a target="_blank"  href="http://pinterest.com/pin/create/button/?url=<?php echo $created_link; ?>"><i class="fab fa-pinterest fa-3x pin anim"></i></a>
                </div>
            </div>
            <div class="col-lg-5 rounded shadow flex-col">
                <div class="col-lg-12">
                    <h3 class="text-center"><strong>Total Hits</strong></h3>
                    <h4 class="text-center"><?php echo $hits; ?></h4>
                    <hr>
                    <h3 class="text-center"><strong>Last Visit</strong></h3>
                    <h4 class="text-center" title="<?php echo $last_visit; ?>"><?php echo time_ago($last_visit); ?></h4>
                    <hr>
                    <h3 class="text-center col-lg-12"><strong>Date Created</strong></h3>
                    <h4 class="text-center col-lg-12" title="<?php echo $date; ?>"><?php echo date('d M Y', strtotime($date)); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.zclip.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $("#copy-button").click(function () {
                $(this).html("Copied!");
                $("#urlbox").select();
                document.execCommand("copy");
            });
        });
    </script>

    <?php
    include "functions/js.php";
    ?>
    
</body>
</html>
<?php
}
$db->close_connection();
?>